package hw.hw4;
// output city, temp, humidity, pressure
public interface WeatherInput {
	public void run();
}
