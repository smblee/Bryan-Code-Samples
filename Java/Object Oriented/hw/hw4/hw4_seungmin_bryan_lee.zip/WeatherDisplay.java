package hw.hw4;

public interface WeatherDisplay {
	public void setWeatherOutput(WeatherOutput wo);
	public void update(WeatherData wd);
	public void display();
}
