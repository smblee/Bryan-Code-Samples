package hw.hw4;

public interface WeatherOutput {
	public void printInfo(String msg);
}
