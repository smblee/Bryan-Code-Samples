package hw.hw5;

public interface StockAnalyst {	
	public float confidenceLevel();
	public String reasons();
	public String get(String key);
}
